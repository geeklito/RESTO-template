if not exists create database cedel;
use database cedel;

create table service(
    id int(11) primary key auto_increment not null,
    nom varchar(50) not null,
    descriptions varchar(250) not null,
    etat int(11) not null,
    datecreated timestamp default current_timestamp
);

create table service_ligne(
    id int(11) primary key auto_increment not null,
    id_services int(11) not null,
    nom varchar(50) not null,
    descriptions varchar(250),
    etat int (11) not null,
    datecreated timestamp default current_timestamp
);

create table langue(
id int(11) primary key auto_increment not null,
nom varchar(50) not null,
datecreated timestamp default current_timestamp
);

create table services_langue(
    id int(11) primary key auto_increment not null,
    id_langue int(11) not null,
    id_services int(11) not null,
    datecreated timestamp default current_timestamp
);
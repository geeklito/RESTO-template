<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width==device-width, initiale-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="images/RC Logo.png" rel="icon" sizes="32x32" type="image/png">
    <title>RC Resto</title>
    <link rel="stylesheet" type="text/css" href="ressources/CSS/menu.css" />
    <link rel="stylesheet" type="text/css" href="ressources/CSS/Resto.css" />
    <link rel="stylesheet" type="text/css" href="ressources/CSS/pied.css" />
    <link rel="stylesheet" href="ressources/CSS/font-awesome.min.css">
</head>

<body>
       <?php 
             include "ressources/fragment/menu.inc";
        ?>
        
            <!---ShowCase-->
            <div class="contenu-img" style=" background-image: url('images/plat.jpg')">
                <div class="contenu-text">
                    <h2 style="background: url('images/ecri.jpg'); background-clip: text;  -webkit-background-clip: text;">
                      Regale Creole
                    </h2>
                    <p>
                      nous nous assurons de rendre chaque moment unique
                    </p>
                    <a href="#info">Commander</a>
                </div>
            </div> 
        </section>
        <!--enfo-->
        <section id="info">
            <div class="info-text">
                <h2>Nos Recettes</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo, esse odit! Consequatur alias a fuga molestiae ratione obcaecati eius laborum blanditiis fugiat natus! Hic labore alias suscipit itaque nemo voluptates.</p>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid veniam corrupti architecto temporibus necessitatibus iusto, quod in sed cumque minus expedita aperiam quibusdam ea dicta atque quidem voluptatum rem aliquam?
                </p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo, esse odit! Consequatur alias a fuga molestiae ratione obcaecati eius laborum blanditiis fugiat natus! Hic labore alias suscipit itaque nemo voluptates.</p>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid veniam corrupti architecto temporibus necessitatibus iusto, quod in sed cumque minus expedita aperiam quibusdam ea dicta atque quidem voluptatum rem aliquam?
                </p>
                
            </div>
            <div class="info-img"> <img style="width:100%; height:90%; border-radius: 50%;" src="images/info.jpg" alt=""> </div>
        </section>
        <section style="background: url('images/contact.jpg') no-repeat center center/cover; height: 570px; overflow: hidden; ">
            <div class="form-container">
                <h1 style="color: #fff">Ecrivez-nous</h1>
                <form action="" method="POST">
                    <div> <input type="text" placeholder="Nom" id="nom"required></div>
                    <div> <input type="tel" placeholder="Telephone" id="prenom" required></div>
                    <div> <input type="email" placeholder="Email" id="email" required></div>
                    <div> <textarea placeholder="Votre Message" name="" id="" cols="30" rows="10">

                    </textarea></div>
                    <button type="submit">Envoyer</button>
                </form>
            </div>
        </section>
      <?php 
      include "ressources/fragment/pied.inc";
      ?>
</body>

</html>
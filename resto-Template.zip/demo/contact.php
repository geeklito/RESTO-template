<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contact</title>
    <link rel="stylesheet" type="text/css" href="ressources/CSS/contact.css" />
    <link rel="stylesheet" type="text/css" href="ressources/CSS/menu.css" />
    <link rel="stylesheet" type="text/css" href="ressources/CSS/pied.css" />
    <link rel="stylesheet" href="ressources/CSS/font-awesome.min.css">
</head>
<body>

        <?php 
             include "ressources/fragment/menu.inc";
        ?>
        <section id="contact" style="background: url('images/contact.jpg')no-repeat center center/cover;">
                <div class="form-container">
                    <h1 style="color: #fff">Ecrivez-nous</h1>
                    <form action="" method="POST">
                        <div> <input type="text" placeholder="Nom" id="nom"required></div>
                        <div> <input type="tel" placeholder="Telephone" id="prenom" required></div>
                        <div> <input type="email" placeholder="Email" id="email" required></div>
                        <div> <textarea placeholder="Votre Message" name="" id="" cols="30" rows="10">
    
                        </textarea></div>
                        <button type="submit">Envoyer</button>
                    </form>
                </div>
            </section>
            <?php 
      include "ressources/fragment/pied.inc";
      ?>
</body>
</html>
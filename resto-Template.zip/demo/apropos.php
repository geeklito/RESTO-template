
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>A propos</title>
    <link rel="stylesheet" type="text/css" href="ressources/CSS/pied.css" />
    <link rel="stylesheet" type="text/css" href="ressources/CSS/menu.css" />
    <link rel="stylesheet" type="text/css" href="ressources/CSS/apropos.css" />
    <link rel="stylesheet" href="ressources/CSS/font-awesome.min.css">
</head>
</head>
<body>
     
        <?php 
             include"ressources/fragment/menu.inc";
        ?>      
    <section id="info">
        <div class="info-text">
            <h2>Presentation</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo, esse odit! Consequatur alias a fuga molestiae ratione obcaecati eius laborum blanditiis fugiat natus! Hic labore alias suscipit itaque nemo voluptates.</p>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid veniam corrupti architecto temporibus necessitatibus iusto, quod in sed cumque minus expedita aperiam quibusdam ea dicta atque quidem voluptatum rem aliquam?
            </p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo, esse odit! Consequatur alias a fuga molestiae ratione obcaecati eius laborum blanditiis fugiat natus! Hic labore alias suscipit itaque nemo voluptates.</p>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid veniam corrupti architecto temporibus necessitatibus iusto, quod in sed cumque minus expedita aperiam quibusdam ea dicta atque quidem voluptatum rem aliquam?
            </p>
        </div>
        <div class="info-img"></div>
        </section>
        <?php 
             include"ressources/fragment/pied.inc";
        ?>
</body>
</html>